from .forma_geometrica import FormaGeometrica
from .analisar import analisar, analisar_forma
from .retangulo import Retangulo
from .figura import Figura